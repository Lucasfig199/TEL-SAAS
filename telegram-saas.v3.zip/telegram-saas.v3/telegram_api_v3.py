# -*- coding: utf-8 -*-
from flask import Flask, request, jsonify, send_from_directory
from telethon import TelegramClient, events
import asyncio
import json
import os
import logging
from datetime import datetime
import threading
import requests

# Configuracao de logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

app = Flask(__name__)

# Caminhos para os arquivos
ACCOUNTS_FILE = 'accounts.json'
CONFIG_FILE = 'config.json'

# Dicionario para armazenar clientes Telethon ativos
telegram_clients = {}

# Dicionario para armazenar o estado de verificacao
pending_verifications = {}

# Variaveis de estatisticas
stats = {'messages_sent': 0, 'messages_received': 0, 'webhook_calls': 0}

# Loop de eventos global para Telethon
telethon_loop = None
telethon_thread = None

# --- Funcoes de Gerenciamento de Configuracao ---

def load_config():
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, 'r') as f:
            try:
                return json.load(f)
            except json.JSONDecodeError:
                logger.error(f"Erro ao decodificar {CONFIG_FILE}. Retornando configuracao padrao.")
                return {'webhook_url': ''}
    return {'webhook_url': ''}

def save_config(config):
    with open(CONFIG_FILE, 'w') as f:
        json.dump(config, f, indent=2)

# --- Funcoes de Gerenciamento de Contas ---

def load_accounts():
    if os.path.exists(ACCOUNTS_FILE):
        with open(ACCOUNTS_FILE, 'r') as f:
            try:
                return json.load(f)
            except json.JSONDecodeError:
                logger.error(f"Erro ao decodificar {ACCOUNTS_FILE}. Retornando lista vazia.")
                return []
    return []

def save_accounts(accounts):
    with open(ACCOUNTS_FILE, 'w') as f:
        json.dump(accounts, f, indent=2)

def run_in_telethon_loop(coro):
    """Executa uma corrotina no loop do Telethon"""
    if telethon_loop and telethon_loop.is_running():
        future = asyncio.run_coroutine_threadsafe(coro, telethon_loop)
        return future.result(timeout=30)
    else:
        raise RuntimeError("Loop do Telethon nao esta disponivel")

async def setup_client_handlers(client, account_data):
    """Configura os handlers de eventos para um cliente"""
    phone = account_data['phone']
    
    @client.on(events.NewMessage(incoming=True))
    async def handler(event):
        try:
            # Verificacao de seguranca para sender e chat
            try:
                sender = await event.get_sender()
                chat = await event.get_chat()
            except Exception as e:
                logger.error(f"Erro ao obter sender/chat para {phone}: {e}")
                return
            
            # Verificar se sender e chat nao sao None
            if not sender:
                logger.warning(f"Sender e None para mensagem em {phone} - pulando")
                return
                
            if not chat:
                logger.warning(f"Chat e None para mensagem em {phone} - pulando")
                return
            
            # Verificar se a mensagem existe
            if not event.message:
                logger.warning(f"Mensagem e None para {phone} - pulando")
                return
            
            message_text = event.message.message or ''
            
            # Detectar tipo de midia
            media_type = None
            if event.message.media:
                if hasattr(event.message.media, 'photo'):
                    media_type = 'photo'
                elif hasattr(event.message.media, 'document'):
                    if hasattr(event.message.media, 'document') and event.message.media.document:
                        if hasattr(event.message.media.document, 'mime_type') and event.message.media.document.mime_type:
                            if 'video' in event.message.media.document.mime_type:
                                media_type = 'video'
                            elif 'audio' in event.message.media.document.mime_type:
                                media_type = 'audio'
                            else:
                                media_type = 'document'
                        else:
                            media_type = 'document'
                    else:
                        media_type = 'document'
                elif hasattr(event.message.media, 'voice'):
                    media_type = 'voice'
                elif hasattr(event.message.media, 'sticker'):
                    media_type = 'sticker'
                elif hasattr(event.message.media, 'contact'):
                    media_type = 'contact'
                elif hasattr(event.message.media, 'geo'):
                    media_type = 'location'
                elif hasattr(event.message.media, 'poll'):
                    media_type = 'poll'
                else:
                    media_type = 'other_media'
            elif message_text:
                media_type = 'text'
            else:
                media_type = 'unknown'

            # Enviar para o webhook configurado
            config = load_config()
            webhook_url = config.get('webhook_url')
            if webhook_url:
                webhook_data = {
                    'event_type': 'message_received',
                    'timestamp': datetime.now().isoformat(),
                    'message': {
                        'id': event.message.id,
                        'text': message_text,
                        'date': event.message.date.isoformat() if event.message.date else datetime.now().isoformat(),
                        'media_type': media_type,
                        'file_path': None,  # Implementar download se necessario
                        'reply_to_message_id': getattr(event.message, 'reply_to_msg_id', None),
                        'has_media': event.message.media is not None,
                    },
                    'sender': {
                        'id': getattr(sender, 'id', None),
                        'username': getattr(sender, 'username', None),
                        'first_name': getattr(sender, 'first_name', ''),
                        'last_name': getattr(sender, 'last_name', ''),
                        'phone': getattr(sender, 'phone', None),
                        'is_bot': getattr(sender, 'bot', False),
                    },
                    'chat': {
                        'id': getattr(chat, 'id', None),
                        'type': 'private' if hasattr(chat, 'first_name') else 'group',
                        'title': getattr(chat, 'title', None),
                        'username': getattr(chat, 'username', None),
                    },
                    'receiver': {
                        'phone': phone,
                        'id': account_data.get('user_id'),
                    },
                }
                
                try:
                    response = requests.post(webhook_url, json=webhook_data, timeout=10)
                    logger.info(f"Webhook enviado para {webhook_url}: {response.status_code}")
                    if response.status_code != 200:
                        logger.warning(f"Webhook retornou status {response.status_code}: {response.text[:200]}")
                    stats['webhook_calls'] += 1
                except requests.exceptions.Timeout:
                    logger.error(f"Timeout ao enviar webhook para {webhook_url}")
                except requests.exceptions.ConnectionError:
                    logger.error(f"Erro de conexao ao enviar webhook para {webhook_url}")
                except Exception as e:
                    logger.error(f"Erro ao enviar webhook: {e}")

            stats['messages_received'] += 1
            logger.info(f"Mensagem recebida para {phone}: {message_text[:50]}...")

        except Exception as e:
            logger.error(f"Erro ao processar mensagem para {phone}: {e}")

async def connect_and_authorize_client(account_data, client=None, code=None):
    """Conecta e autoriza um cliente Telethon, ou continua a autorizacao com um codigo."""
    phone = account_data['phone']
    api_id = account_data['api_id']
    api_hash = account_data['api_hash']
    session_name = f'session_{phone.replace("+", "")}'

    if not client:
        client = TelegramClient(session_name, api_id, api_hash, loop=telethon_loop)

    try:
        await client.connect()
        if not await client.is_user_authorized():
            if code:
                await client.sign_in(phone, code)
            else:
                await client.send_code_request(phone)
                return {'status': 'pending_verification', 'needs_verification': True, 'phone': phone, 'client_obj': client}
        
        # Se chegou aqui, o cliente esta autorizado
        await setup_client_handlers(client, account_data)
        
        me = await client.get_me()
        account_data['user_id'] = me.id
        account_data['name'] = me.first_name + (f' {me.last_name}' if me.last_name else '')
        account_data['connected'] = True
        account_data['last_seen'] = datetime.now().isoformat()
        
        telegram_clients[phone] = client
        logger.info(f"Cliente Telethon para {phone} conectado como {me.first_name}")
        return {'status': 'success', 'message': 'Conta conectada com sucesso'}
        
    except Exception as e:
        logger.error(f"Erro ao conectar/autorizar cliente Telethon para {phone}: {e}")
        account_data['connected'] = False
        return {'status': 'error', 'error': str(e)}

async def telethon_main():
    """Funcao principal do loop do Telethon"""
    logger.info("Iniciando loop do Telethon...")
    
    # Inicializar clientes existentes
    accounts = load_accounts()
    for account in accounts:
        if account.get('connected', False):
            logger.info(f"Tentando reconectar conta {account['phone']}...")
            try:
                result = await connect_and_authorize_client(account)
                if result['status'] == 'error':
                    logger.error(f"Falha ao reconectar {account['phone']}: {result['error']}")
            except Exception as e:
                logger.error(f"Erro ao reconectar {account['phone']}: {e}")
    
    save_accounts(accounts)
    
    # Manter o loop rodando
    while True:
        await asyncio.sleep(1)

def start_telethon_thread():
    """Inicia o thread do Telethon"""
    global telethon_loop, telethon_thread
    
    def run_telethon():
        global telethon_loop
        telethon_loop = asyncio.new_event_loop()
        asyncio.set_event_loop(telethon_loop)
        telethon_loop.run_until_complete(telethon_main())
    
    telethon_thread = threading.Thread(target=run_telethon, daemon=True)
    telethon_thread.start()
    
    # Aguardar o loop estar pronto
    import time
    time.sleep(2)
    logger.info("Thread do Telethon iniciado")

# --- Rotas da API ---

@app.route('/')
def dashboard():
    return send_from_directory('static', 'index.html')

@app.route('/static/<path:filename>')
def static_files(filename):
    return send_from_directory('static', filename)

@app.route('/api/set-webhook', methods=['POST'])
def set_webhook():
    data = request.json
    webhook_url = data.get('webhook_url', '')
    config = load_config()
    config['webhook_url'] = webhook_url
    save_config(config)
    logger.info(f"Webhook URL atualizada: {webhook_url}")
    return jsonify({'status': 'success', 'message': 'Webhook URL atualizada com sucesso'}), 200

@app.route('/api/get-config', methods=['GET'])
def get_config():
    config = load_config()
    return jsonify(config), 200

@app.route('/api/connect-account', methods=['POST'])
def connect_account():
    data = request.json
    phone = data.get('phone')
    api_id = data.get('api_id')
    api_hash = data.get('api_hash')

    if not all([phone, api_id, api_hash]):
        return jsonify({'status': 'error', 'error': 'Dados incompletos'}), 400

    try:
        async def _connect():
            accounts = load_accounts()
            existing_account = next((acc for acc in accounts if acc['phone'] == phone), None)

            if existing_account and existing_account.get('connected'):
                return {'status': 'error', 'error': 'Conta ja conectada'}

            account_data = existing_account or {
                'phone': phone,
                'api_id': api_id,
                'api_hash': api_hash,
                'active': len(accounts) == 0,  # Primeira conta e ativa por padrao
                'connected': False,
                'name': 'Usuario',
                'user_id': None,
                'last_seen': None,
            }

            if not existing_account:
                accounts.append(account_data)
                save_accounts(accounts)

            result = await connect_and_authorize_client(account_data)
            if result['status'] == 'pending_verification':
                # Armazenar o cliente para a proxima etapa de verificacao
                pending_verifications[phone] = result.pop('client_obj')
            return result

        result = run_in_telethon_loop(_connect())
        return jsonify(result), 200 if result['status'] != 'error' else 400

    except Exception as e:
        logger.error(f"Erro ao conectar conta {phone}: {e}")
        return jsonify({'status': 'error', 'error': str(e)}), 500

@app.route('/api/verify-code', methods=['POST'])
def verify_code():
    data = request.json
    phone = data.get('phone')
    code = data.get('code')

    if not all([phone, code]):
        return jsonify({'status': 'error', 'error': 'Telefone e codigo sao obrigatorios'}), 400

    try:
        async def _verify():
            client = pending_verifications.get(phone)
            if not client:
                return {'status': 'error', 'error': 'Nenhuma verificacao pendente para este telefone'}

            accounts = load_accounts()
            account_data = next((acc for acc in accounts if acc['phone'] == phone), None)
            if not account_data:
                return {'status': 'error', 'error': 'Conta nao encontrada'}

            result = await connect_and_authorize_client(account_data, client=client, code=code)
            if result['status'] == 'success':
                del pending_verifications[phone]
                save_accounts(accounts)
            return result

        result = run_in_telethon_loop(_verify())
        return jsonify(result), 200 if result['status'] != 'error' else 400

    except Exception as e:
        logger.error(f"Erro ao verificar codigo para {phone}: {e}")
        return jsonify({'status': 'error', 'error': str(e)}), 500

@app.route('/api/accounts', methods=['GET'])
def get_accounts():
    accounts = load_accounts()
    # Atualizar status de conexao em tempo real
    for acc in accounts:
        acc['connected'] = acc['phone'] in telegram_clients and telegram_clients[acc['phone']].is_connected()
    return jsonify({'accounts': accounts}), 200

@app.route('/api/set-active-account', methods=['POST'])
def set_active_account():
    data = request.json
    phone = data.get('phone')

    accounts = load_accounts()
    found = False
    for acc in accounts:
        if acc['phone'] == phone:
            acc['active'] = True
            found = True
        else:
            acc['active'] = False
    save_accounts(accounts)

    if not found:
        return jsonify({'status': 'error', 'error': 'Conta nao encontrada'}), 404
    return jsonify({'status': 'success', 'message': f'Conta {phone} definida como ativa'}), 200

@app.route('/api/remove-account', methods=['DELETE'])
def remove_account():
    data = request.json
    phone = data.get('phone')

    try:
        async def _remove():
            if phone in telegram_clients:
                client = telegram_clients.pop(phone)
                await client.disconnect()
                logger.info(f"Cliente Telethon para {phone} desconectado")

        if phone in telegram_clients:
            run_in_telethon_loop(_remove())

        accounts = load_accounts()
        initial_len = len(accounts)
        accounts = [acc for acc in accounts if acc['phone'] != phone]
        save_accounts(accounts)

        if len(accounts) == initial_len:
            return jsonify({'status': 'error', 'error': 'Conta nao encontrada'}), 404

        # Remover arquivo de sessao
        session_file = f'session_{phone.replace("+", "")}.session'
        if os.path.exists(session_file):
            os.remove(session_file)
            logger.info(f"Arquivo de sessao {session_file} removido")

        return jsonify({'status': 'success', 'message': f'Conta {phone} removida com sucesso'}), 200

    except Exception as e:
        logger.error(f"Erro ao remover conta {phone}: {e}")
        return jsonify({'status': 'error', 'error': str(e)}), 500

def get_active_client():
    accounts = load_accounts()
    active_account = next((acc for acc in accounts if acc.get('active')), None)
    if active_account and active_account['phone'] in telegram_clients:
        return telegram_clients[active_account['phone']]
    
    # Fallback para a primeira conta conectada
    for acc in accounts:
        if acc['phone'] in telegram_clients:
            return telegram_clients[acc['phone']]
            
    return None

@app.route('/api/send-message', methods=['POST'])
def send_message():
    data = request.json
    chat_id = data.get('chat_id')
    message = data.get('message')

    if not all([chat_id, message]):
        return jsonify({'status': 'error', 'error': 'Chat ID e mensagem sao obrigatorios'}), 400

    try:
        async def _send():
            client = get_active_client()
            if not client:
                return {'status': 'error', 'error': 'Nenhuma conta Telegram conectada ou ativa'}

            # Tentar converter chat_id para int, se for um numero
            try:
                chat_id_int = int(chat_id)
            except ValueError:
                chat_id_int = chat_id # Manter como string se nao for numero (ex: @username)

            await client.send_message(chat_id_int, message)
            stats['messages_sent'] += 1
            return {'status': 'success', 'message': 'Mensagem enviada com sucesso'}

        result = run_in_telethon_loop(_send())
        return jsonify(result), 200 if result['status'] != 'error' else 401

    except Exception as e:
        logger.error(f"Erro ao enviar mensagem: {e}")
        return jsonify({'status': 'error', 'error': str(e)}), 500

@app.route('/api/send-photo', methods=['POST'])
def send_photo():
    data = request.json
    chat_id = data.get('chat_id')
    photo_url = data.get('photo_url')
    caption = data.get('caption', None)

    if not all([chat_id, photo_url]):
        return jsonify({'status': 'error', 'error': 'Chat ID e URL da foto sao obrigatorios'}), 400

    try:
        async def _send():
            client = get_active_client()
            if not client:
                return {'status': 'error', 'error': 'Nenhuma conta Telegram conectada ou ativa'}

            # Tentar converter chat_id para int, se for um numero
            try:
                chat_id_int = int(chat_id)
            except ValueError:
                chat_id_int = chat_id # Manter como string se nao for numero (ex: @username)

            await client.send_file(chat_id_int, photo_url, caption=caption)
            stats['messages_sent'] += 1
            return {'status': 'success', 'message': 'Foto enviada com sucesso'}

        result = run_in_telethon_loop(_send())
        return jsonify(result), 200 if result['status'] != 'error' else 401

    except Exception as e:
        logger.error(f"Erro ao enviar foto: {e}")
        return jsonify({'status': 'error', 'error': str(e)}), 500

@app.route('/api/send-video', methods=['POST'])
def send_video():
    data = request.json
    chat_id = data.get('chat_id')
    video_url = data.get('video_url')
    caption = data.get('caption', None)

    if not all([chat_id, video_url]):
        return jsonify({'status': 'error', 'error': 'Chat ID e URL do video sao obrigatorios'}), 400

    try:
        async def _send():
            client = get_active_client()
            if not client:
                return {'status': 'error', 'error': 'Nenhuma conta Telegram conectada ou ativa'}

            # Tentar converter chat_id para int, se for um numero
            try:
                chat_id_int = int(chat_id)
            except ValueError:
                chat_id_int = chat_id # Manter como string se nao for numero (ex: @username)

            await client.send_file(chat_id_int, video_url, caption=caption)
            stats['messages_sent'] += 1
            return {'status': 'success', 'message': 'Video enviado com sucesso'}

        result = run_in_telethon_loop(_send())
        return jsonify(result), 200 if result['status'] != 'error' else 401

    except Exception as e:
        logger.error(f"Erro ao enviar video: {e}")
        return jsonify({'status': 'error', 'error': str(e)}), 500

@app.route('/api/send-audio', methods=['POST'])
def send_audio():
    data = request.json
    chat_id = data.get('chat_id')
    audio_url = data.get('audio_url')
    caption = data.get('caption', None)

    if not all([chat_id, audio_url]):
        return jsonify({'status': 'error', 'error': 'Chat ID e URL do audio sao obrigatorios'}), 400

    try:
        async def _send():
            client = get_active_client()
            if not client:
                return {'status': 'error', 'error': 'Nenhuma conta Telegram conectada ou ativa'}

            # Tentar converter chat_id para int, se for um numero
            try:
                chat_id_int = int(chat_id)
            except ValueError:
                chat_id_int = chat_id # Manter como string se nao for numero (ex: @username)

            await client.send_file(chat_id_int, audio_url, caption=caption)
            stats['messages_sent'] += 1
            return {'status': 'success', 'message': 'Audio enviado com sucesso'}

        result = run_in_telethon_loop(_send())
        return jsonify(result), 200 if result['status'] != 'error' else 401

    except Exception as e:
        logger.error(f"Erro ao enviar audio: {e}")
        return jsonify({'status': 'error', 'error': str(e)}), 500

@app.route('/api/status', methods=['GET'])
def get_status():
    accounts = load_accounts()
    for acc in accounts:
        acc['connected'] = acc['phone'] in telegram_clients and telegram_clients[acc['phone']].is_connected()
    return jsonify({'status': 'online', 'accounts': accounts, 'stats': stats}), 200

if __name__ == '__main__':
    # Iniciar thread do Telethon
    start_telethon_thread()
    
    # Iniciar Flask
    logger.info("Iniciando servidor Flask...")
    app.run(host='0.0.0.0', port=5000)

